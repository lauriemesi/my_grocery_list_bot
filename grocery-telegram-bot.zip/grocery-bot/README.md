# 🛒 בוט רשימת סופר - Telegram

## הוראות התקנה

### שלב 1 — צור בוט ב-Telegram
1. פתח Telegram וחפש **@BotFather**
2. שלח `/newbot`
3. תן שם: `רשימת סופר`
4. תן username: `my_grocery_bot` (חייב להסתיים ב-bot)
5. שמור את ה-TOKEN שתקבל

### שלב 2 — הרץ על המחשב (לבדיקה)
```bash
# התקן Python 3.10+
pip install python-telegram-bot==20.7

# הגדר את הטוקן
export BOT_TOKEN="הטוקן שלך כאן"

# הרץ
python bot.py
```

### שלב 3 — הרץ בענן (בחינם, 24/7)

#### אפשרות א׳ — Railway.app (הכי קל)
1. כנס ל-railway.app והירשם
2. לחץ "New Project" ← "Deploy from GitHub"
3. העלה את הקבצים ל-GitHub repository
4. הוסף משתנה סביבה: `BOT_TOKEN = הטוקן שלך`
5. הבוט יעלה אוטומטית!

#### אפשרות ב׳ — Render.com (חינם)
1. כנס ל-render.com
2. New ← Web Service ← העלה מ-GitHub
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `python bot.py`
5. הוסף Environment Variable: `BOT_TOKEN`

## פקודות הבוט
- שלח שם מוצר → נוסף לרשימה
- שלח כמה מוצרים בשורות נפרדות → נוספים ביחד
- `/list` — הצג רשימה עם כפתורים
- `/done 1` — סמן פריט 1 כנקנה
- `/del 1` — מחק פריט 1
- `/clear` — נקה פריטים שנקנו
- `/clearall` — נקה הכל
- `/stats` — סטטיסטיקה
- `/share` — שתף את הרשימה כטקסט

## שיתוף עם בן/בת זוג
הוסף את הבוט לקבוצת Telegram עם בן/בת הזוג —
שניכם יראו ויערכו את אותה הרשימה!
