import os
import json
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# ── הגדרות ──────────────────────────────────────
TOKEN = os.environ.get("BOT_TOKEN", "YOUR_TOKEN_HERE")
DATA_FILE = "grocery_data.json"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)

# ── שמירת נתונים ────────────────────────────────
def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_list(chat_id: str, data: dict) -> dict:
    if chat_id not in data:
        data[chat_id] = {"items": [], "next_id": 1}
    return data[chat_id]

# ── קטגוריות ────────────────────────────────────
CATEGORIES = {
    "ירקות": "🥦", "פירות": "🍎", "חלב": "🥛",
    "בשר": "🥩", "לחם": "🍞", "ניקיון": "🧼", "שונות": "📦"
}

CAT_KEYWORDS = {
    "ירקות": ["עגבנייה","מלפפון","גזר","פלפל","חסה","כרוב","בצל","שום","תפוח אדמה"],
    "פירות": ["תפוח","בננה","תפוז","ענב","אבטיח","מלון","תות","לימון","מנגו"],
    "חלב":   ["חלב","גבינה","יוגורט","שמנת","חמאה","קוטג","לבן","ביצה"],
    "בשר":   ["עוף","בשר","דג","סלמון","קציצה","נקניק","שניצל"],
    "לחם":   ["לחם","פיתה","לחמנייה","בייגלה","קרואסון","עוגה","קרקר"],
    "ניקיון":["סבון","אבקה","ניקיון","נייר","מגבת","מגבון","שמפו"],
}

def detect_category(name: str) -> str:
    for cat, keywords in CAT_KEYWORDS.items():
        if any(kw in name for kw in keywords):
            return cat
    return "שונות"

def parse_item(text: str) -> tuple[str, str]:
    """מחזיר (שם, כמות) מתוך טקסט חופשי"""
    import re
    # "2 ליטר חלב" → שם=חלב, כמות=2 ליטר
    m = re.match(r'^(\d+(?:\s*(?:יחידות?|ק"ג|קג|ליטר|מ"ל|גרם|ג\'))?)\s+(.+)', text)
    if m:
        return m.group(2).strip(), m.group(1).strip()
    # "חלב x2"
    m = re.match(r'^(.+?)\s+[xX×](\d+)$', text)
    if m:
        return m.group(1).strip(), f"×{m.group(2)}"
    return text.strip(), ""

# ── פורמט רשימה ─────────────────────────────────
def format_list(chat_data: dict, show_ids=False) -> str:
    items = chat_data.get("items", [])
    if not items:
        return "📋 הרשימה ריקה!\n\nשלח שם מוצר כדי להוסיף 👇"

    done = [i for i in items if i["done"]]
    pending = [i for i in items if not i["done"]]
    total = len(items)
    pct = round(len(done) / total * 100) if total else 0

    # Progress bar
    filled = round(pct / 10)
    bar = "▓" * filled + "░" * (10 - filled)
    text = f"🛒 *רשימת הקניות* | {len(done)}/{total} נקנו\n`{bar}` {pct}%\n\n"

    # Group by category
    cats = {}
    for item in pending:
        cat = item.get("cat", "שונות")
        cats.setdefault(cat, []).append(item)

    for cat, emoji in CATEGORIES.items():
        if cat not in cats:
            continue
        text += f"{emoji} *{cat}*\n"
        for item in cats[cat]:
            id_str = f"`#{item['id']}` " if show_ids else ""
            qty = f" _{item['qty']}_" if item.get("qty") else ""
            text += f"  ⬜ {id_str}{item['name']}{qty}\n"
        text += "\n"

    if done:
        text += "✅ *נקנו:*\n"
        for item in done:
            text += f"  ~~{item['name']}~~\n"

    return text

def main_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ סמן נקנה", callback_data="mark"),
            InlineKeyboardButton("🗑️ מחק", callback_data="delete"),
        ],
        [
            InlineKeyboardButton("🧹 נקה שנקנו", callback_data="clear_done"),
            InlineKeyboardButton("📊 סטטיסטיקה", callback_data="stats"),
        ],
        [
            InlineKeyboardButton("🔄 רענן", callback_data="refresh"),
            InlineKeyboardButton("🗑️ נקה הכל", callback_data="clear_all"),
        ],
    ])

# ── פקודות ──────────────────────────────────────
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 *שלום! אני בוט רשימת הסופר שלך* 🛒\n\n"
        "פשוט שלח לי שם מוצר ואוסיף אותו לרשימה!\n\n"
        "*פקודות:*\n"
        "/list — הצג רשימה\n"
        "/done 1 — סמן פריט מספר 1 כנקנה\n"
        "/del 1 — מחק פריט מספר 1\n"
        "/clear — נקה פריטים שנקנו\n"
        "/clearall — נקה הכל\n"
        "/share — שתף את הרשימה\n"
        "/stats — סטטיסטיקה\n\n"
        "💡 *טיפ:* הוסף אותי לקבוצה עם בן/בת הזוג לרשימה משותפת!"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def cmd_list(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)
    text = format_list(chat_data)
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_keyboard())

async def cmd_done(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)

    if not ctx.args:
        await update.message.reply_text("שלח: /done [מספר]\nלדוג׳: `/done 1`", parse_mode="Markdown")
        return

    item_id = int(ctx.args[0])
    items = chat_data["items"]
    item = next((i for i in items if i["id"] == item_id), None)

    if not item:
        await update.message.reply_text(f"❌ לא נמצא פריט #{item_id}")
        return

    item["done"] = not item["done"]
    save_data(data)
    status = "✅ נקנה" if item["done"] else "⬜ לא נקנה"
    await update.message.reply_text(f"{status}: *{item['name']}*", parse_mode="Markdown")

async def cmd_del(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)

    if not ctx.args:
        await update.message.reply_text("שלח: /del [מספר]\nלדוג׳: `/del 1`", parse_mode="Markdown")
        return

    item_id = int(ctx.args[0])
    items = chat_data["items"]
    item = next((i for i in items if i["id"] == item_id), None)

    if not item:
        await update.message.reply_text(f"❌ לא נמצא פריט #{item_id}")
        return

    chat_data["items"] = [i for i in items if i["id"] != item_id]
    save_data(data)
    await update.message.reply_text(f"🗑️ נמחק: *{item['name']}*", parse_mode="Markdown")

async def cmd_clear(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)
    before = len(chat_data["items"])
    chat_data["items"] = [i for i in chat_data["items"] if not i["done"]]
    removed = before - len(chat_data["items"])
    save_data(data)
    await update.message.reply_text(f"🧹 הוסרו {removed} פריטים שנקנו.")

async def cmd_clearall(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    data[chat_id] = {"items": [], "next_id": 1}
    save_data(data)
    await update.message.reply_text("🗑️ הרשימה נוקתה לגמרי!")

async def cmd_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)
    items = chat_data.get("items", [])
    total = len(items)
    done = sum(1 for i in items if i["done"])
    cats = len(set(i.get("cat","שונות") for i in items))
    text = (
        f"📊 *סטטיסטיקה*\n\n"
        f"📋 סה״כ פריטים: {total}\n"
        f"✅ נקנו: {done}\n"
        f"⬜ נותרו: {total - done}\n"
        f"📁 קטגוריות: {cats}\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def cmd_share(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)
    items = [i for i in chat_data.get("items",[]) if not i["done"]]
    if not items:
        await update.message.reply_text("הרשימה ריקה!")
        return
    lines = "\n".join(f"⬜ {i['name']}" + (f" ({i['qty']})" if i.get("qty") else "") for i in items)
    await update.message.reply_text(f"🛒 *רשימת קניות:*\n\n{lines}", parse_mode="Markdown")

# ── הודעות טקסט חופשי ───────────────────────────
async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text or text.startswith("/"):
        return

    data = load_data()
    chat_id = str(update.effective_chat.id)
    chat_data = get_list(chat_id, data)

    # פענוח שורות מרובות
    lines = [l.strip() for l in text.split("\n") if l.strip()]
    added = []

    for line in lines:
        name, qty = parse_item(line)
        cat = detect_category(name)
        item = {
            "id": chat_data["next_id"],
            "name": name,
            "qty": qty,
            "cat": cat,
            "done": False,
        }
        chat_data["items"].append(item)
        chat_data["next_id"] += 1
        emoji = CATEGORIES.get(cat, "📦")
        added.append(f"{emoji} {name}" + (f" _{qty}_" if qty else ""))

    save_data(data)

    if len(added) == 1:
        reply = f"✅ נוסף: {added[0]}\n\nרשימה: {len(chat_data['items'])} פריטים"
    else:
        items_str = "\n".join(f"  • {a}" for a in added)
        reply = f"✅ נוספו {len(added)} פריטים:\n{items_str}"

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("📋 הצג רשימה", callback_data="refresh"),
    ]])
    await update.message.reply_text(reply, parse_mode="Markdown", reply_markup=keyboard)

# ── כפתורים ─────────────────────────────────────
async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data_cb = query.data
    chat_id = str(query.message.chat_id)

    data = load_data()
    chat_data = get_list(chat_id, data)

    if data_cb == "refresh":
        text = format_list(chat_data)
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=main_keyboard())

    elif data_cb == "mark":
        items = [i for i in chat_data["items"] if not i["done"]]
        if not items:
            await query.answer("אין פריטים לסימון!", show_alert=True)
            return
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(
                f"{CATEGORIES.get(i['cat'],'📦')} {i['name']}", 
                callback_data=f"toggle_{i['id']}"
            )] for i in items
        ] + [[InlineKeyboardButton("↩️ חזור", callback_data="refresh")]])
        await query.edit_message_text("בחר פריט לסימון כנקנה:", reply_markup=keyboard)

    elif data_cb == "delete":
        items = chat_data["items"]
        if not items:
            await query.answer("הרשימה ריקה!", show_alert=True)
            return
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(
                f"{'✅' if i['done'] else '⬜'} {i['name']}", 
                callback_data=f"del_{i['id']}"
            )] for i in items
        ] + [[InlineKeyboardButton("↩️ חזור", callback_data="refresh")]])
        await query.edit_message_text("בחר פריט למחיקה:", reply_markup=keyboard)

    elif data_cb.startswith("toggle_"):
        item_id = int(data_cb.split("_")[1])
        item = next((i for i in chat_data["items"] if i["id"] == item_id), None)
        if item:
            item["done"] = not item["done"]
            save_data(data)
        # חזור לרשימה
        text = format_list(chat_data)
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=main_keyboard())

    elif data_cb.startswith("del_"):
        item_id = int(data_cb.split("_")[1])
        item = next((i for i in chat_data["items"] if i["id"] == item_id), None)
        if item:
            chat_data["items"] = [i for i in chat_data["items"] if i["id"] != item_id]
            save_data(data)
        text = format_list(chat_data)
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=main_keyboard())

    elif data_cb == "clear_done":
        before = len(chat_data["items"])
        chat_data["items"] = [i for i in chat_data["items"] if not i["done"]]
        removed = before - len(chat_data["items"])
        save_data(data)
        text = format_list(chat_data)
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=main_keyboard())
        await query.answer(f"🧹 הוסרו {removed} פריטים")

    elif data_cb == "clear_all":
        data[chat_id] = {"items": [], "next_id": 1}
        save_data(data)
        await query.edit_message_text(
            "🗑️ הרשימה נוקתה!\n\nשלח שם מוצר להוספה 👇",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📋 הצג רשימה", callback_data="refresh")
            ]])
        )

    elif data_cb == "stats":
        items = chat_data.get("items", [])
        total = len(items)
        done = sum(1 for i in items if i["done"])
        text = (
            f"📊 *סטטיסטיקה*\n\n"
            f"📋 סה״כ: {total} פריטים\n"
            f"✅ נקנו: {done}\n"
            f"⬜ נותרו: {total - done}\n"
        )
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("↩️ חזור", callback_data="refresh")]])
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=keyboard)

# ── הפעלה ────────────────────────────────────────
def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("list", cmd_list))
    app.add_handler(CommandHandler("done", cmd_done))
    app.add_handler(CommandHandler("del", cmd_del))
    app.add_handler(CommandHandler("clear", cmd_clear))
    app.add_handler(CommandHandler("clearall", cmd_clearall))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("share", cmd_share))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🛒 בוט רשימת סופר פועל!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
